The documentation for developing modules using the MaduleAdmin class is at:

http://sf.net/projects/xoops/files/XOOPS%20Documentation_Development/XOOPS_ModuleDevelopmentGuide/Frameworks_moduleadmin_en.pdf/download