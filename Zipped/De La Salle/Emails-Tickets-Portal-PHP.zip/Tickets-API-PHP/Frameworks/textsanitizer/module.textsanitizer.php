<?php
// For backward compatibility
/**
 * Class MyTextSanitizerExtended
 */
class MyTextSanitizerExtended extends MyTextSanitizer
{
}
