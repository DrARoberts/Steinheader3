<?php
/**
 * Xoops Frameworks addon: art
 *
 * @copyright       (c) 2000-2016 XOOPS Project (www.xoops.org)
 * @license             GNU GPL 2 (http://www.gnu.org/licenses/gpl-2.0.html)
 * @author              Taiwen Jiang <phppp@users.sourceforge.net>
 * @since               1.00
 * @package             Frameworks
 */

define('XOOPS_FRAMEWORKS_ART_VERSION', '1.0.0');
