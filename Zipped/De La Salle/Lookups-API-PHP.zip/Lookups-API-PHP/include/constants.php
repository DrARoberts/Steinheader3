<?php
/**
 * API constants file
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright       (c) 2000-2016 API Project (www.api.org)
 * @license             GNU GPL 2 (http://www.gnu.org/licenses/gpl-2.0.html)
 */


// GeoIP Local Database Paths
define('API_GEOIP_LITECITY','/usr/share/GeoIP/GeoLiteCity.dat');
define('API_GEOIP_IPASNUM','/usr/share/GeoIP/GeoIPASNum.dat');
define('API_GEOIP_IPASNUM2','/usr/share/GeoIP/GeoIPASNum2.dat');
define('API_GEOIP_IPASNUMV6','/usr/share/GeoIP/GeoIPASNumv6.dat');
define('API_GEOIP_LITECITYV6','/usr/share/GeoIP/GeoLiteCityv6.dat');
define('API_GEOIP_IPASNUM2V6','/usr/share/GeoIP/GeoIPASNum2v6.dat');
define('API_GEOIP_IPV6','/usr/share/GeoIP/GeoIPv6.dat');
define('API_GEOIP_IPCITYV4', '');
define('API_GEOIP_IPV4','/usr/share/GeoIP/GeoIP.dat');
define('API_GEOIP_IPNETSPEED','/usr/share/GeoIP/GeoIPNetSpeed.dat');
define('API_GEOIP_IPNETSPEEDCELL','/usr/share/GeoIP/GeoIPNetSpeedCell.dat');
define('API_GEOIP_IPORG','/usr/share/GeoIP/GeoIPOrg.dat');
define('API_GEOIP_IPISP','/usr/share/GeoIP/GeoIPISP.dat');
define('API_GEOIP_IPREGION','/usr/share/GeoIP/GeoIPRegion.dat');
define('API_GEOIP_IPDOMAIN','/usr/share/GeoIP/GeoIPDomain.dat');
define('API_GEOIP_ENABLED','country,city,ipv4,ipv6,iporg,ipdomain,litecity,litecityv6,ipasnum,ipasnum2,ipasnumv6,ipasnum2v6');

// ipinfodb.com - API KEY
define('API_IPINFODB_KEY','283d127fc483d15100ab203fc88c1345f87aa08449d291235740e88ea9b62500');

// Methods of Calling =? 'geoip,ipinfodb'
define('API_METHODS','ipinfodb,geoip');

