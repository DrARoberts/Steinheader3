<?php
/**
 * YOU SHOULD NEVER TOUCH THIS FILE, IT WILL BE REMOVED
 */
/*
 You may not change or alter any portion of this comment or credits
 of supporting developers from this source code or any supporting source code
 which is considered copyrighted (c) material of the original comment or credit authors.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/**
 *  API Version
 *
 * @copyright       (c) 2000-2017 API Project (www.api.org)
 * @license             GNU GPL 2 or later (http://www.gnu.org/licenses/gpl-2.0.html)
 * @deprecated
 */
defined('API_ROOT_PATH') || exit('Restricted access');

define('API_LICENSE_CODE', 'GPL');
define('API_LICENSE_TEXT', 'GPL General Public License (GPL) (v. 2.0)');
define('API_LICENSE_KEY', '000000-000000-000000-000000-0000000');
define('API_LICENSE_COMPANY', '');
define('API_LICENSE_UNAME', '');
define('API_LICENSE_EMAIL', '');
define('API_LICENSE_PASSWORD', '');
define('API_LICENSE_PROTOCOL', '');
define('API_LICENSE_REALM', '');
define('API_LICENSE_PATH', '');
define('API_LICENSE_TYPE', '');