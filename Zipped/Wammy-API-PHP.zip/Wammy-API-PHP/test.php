<?php
/**
 * Chronolabs Fonting Repository Services REST API API
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright       Chronolabs Cooperative http://labs.coop
 * @license         General Public License version 3 (http://labs.coop/briefs/legal/general-public-licence/13,3.html)
 * @package         fonts
 * @since           2.1.9
 * @author          Simon Roberts <wishcraft@users.sourceforge.net>
 * @subpackage		api
 * @description		Fonting Repository Services REST API
 * @link			http://sourceforge.net/projects/chronolabsapis
 * @link			http://cipher.labs.coop
 */

global $sessionid, $source;
require_once __DIR__ . DIRECTORY_SEPARATOR . 'header.php';

$GLOBALS['APIDB']->queryF("START TRANSACTION");

/**
 * URI Path Finding of API URL Source Locality
 * @var unknown_type
 */
$odds = $inner = array();
foreach($inner as $key => $values) {
    if (!isset($inner[$key])) {
        $inner[$key] = $values;
    } elseif (!in_array(!is_array($values) ? $values : md5(json_encode($values, true)), array_keys($odds[$key]))) {
        if (is_array($values)) {
            $odds[$key][md5(json_encode($inner[$key] = $values, true))] = $values;
        } else {
            $odds[$key][$inner[$key] = $values] = "$values--$key";
        }
    }
}

foreach($_POST as $key => $values) {
    if (!isset($inner[$key])) {
        $inner[$key] = $values;
    } elseif (!in_array(!is_array($values) ? $values : md5(json_encode($values, true)), array_keys($odds[$key]))) {
        if (is_array($values)) {
            $odds[$key][md5(json_encode($inner[$key] = $values, true))] = $values;
        } else {
            $odds[$key][$inner[$key] = $values] = "$values--$key";
        }
    }
}

foreach(parse_url('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'].(strpos($_SERVER['REQUEST_URI'], '?')?'&':'?').$_SERVER['QUERY_STRING'], PHP_URL_QUERY) as $key => $values) {
    if (!isset($inner[$key])) {
        $inner[$key] = $values;
    } elseif (!in_array(!is_array($values) ? $values : md5(json_encode($values, true)), array_keys($odds[$key]))) {
        if (is_array($values)) {
            $odds[$key][md5(json_encode($inner[$key] = $values, true))] = $values;
        } else {
            $odds[$key][$inner[$key] = $values] = "$values--$key";
        }
    }
}


$data = $errors = array();
$version = isset($inner['version'])?(string)$inner['version']:'v4';
$state = isset($inner['state'])?(string)$inner['state']:'raw';
$mode = isset($inner['mode'])?(string)$inner['mode']:'return';
$output = isset($inner['output'])?(string)$inner['output']:'test';
$inner['mimetype'] = isset($inner['mimetype'])?(string)$inner['mimetype']:'text/plain';
switch($output)
{
    case "test":
        
        if (!isset($inner['subject']) || empty($inner['subject']))
            $errors['missing_subject'] = "Field \$_POST['subject'] is an essential field for this function ~ you must specify it!";
        if (!isset($inner['message']) || empty($inner['message']))
            $errors['missing_message'] = "Field \$_POST['message'] is an essential field for this function ~ you must specify it!";
        if (!isset($inner['sender-ip']) || empty($inner['sender-ip']))
            $errors['missing_senderip'] = "Field \$_POST['sender-ip'] is an essential field for this function ~ you must specify it!";
        if (!isset($inner['usernames']['sender']) || empty($inner['usernames']['sender']))
            $errors['missing_username_sender'] = "Field \$_POST['usernames']['sender'] is an essential field for this function ~ you must specify it!";
        if (!isset($inner['usernames']['recipient']) || empty($inner['usernames']['recipient']))
            $errors['missing_username_recipient'] = "Field \$_POST['usernames']['recipient'] is an essential field for this function ~ you must specify it!";
        if (!isset($inner['mimetype']) || empty($inner['mimetype']))
            $errors['missing_mimetype'] = "Field \$_POST['mimetype'] is an essential field for this function ~ you must specify it!";
        if (!in_array($state, array('return','xml','serial','json')))
            $errors['wrong_state'] = "Field \$_POST['state'] is an essential field and is enumerated to only one of the following: return, xml, serial, json!";
        if (!in_array($inner['mimetype'], array('text/plain','text/html')))
            $errors['wrong_mimetype'] = "Field \$_POST['mimetype'] is an essential field and is enumerated to only one of the following: text/plain, text/html!";
        if ($state=='return' && !isset($inner['return']) &&  empty($inner['return']))
            $errors['missing_return'] = "Field \$_POST['return'] is an essential field for this function for a URL to be specified to return the call to the API in the browser ~ you must specify it!";
        if ($state=='return' && !isset($inner['callback']) &&  empty($inner['callback']))
            $errors['missing_callback'] = "Field \$_POST['callback'] is an essential field for this function for a URL to be called by the callback cron and sent the testing data after returned to the source in the browser ~ you must specify it!";
        break;
}

if ($country == 'random' || $place == 'random')
    $keyname = md5(whitelistGetIP(true) . '___' . $_SERVER['HTTP_HOST'] . '___' . $_SERVER['REQUEST_URI'] . '_____' . json_encode($inner));
else
    $keyname = md5($_SERVER['REQUEST_URI'] . json_encode($inner));
if (!$data = APICache::read($keyname))
{
    if (count($errors)>0) {
        if (function_exists('http_response_code'))
            http_response_code(500);
            $data = array('state' => 'error occured', 'errors'=>$errors, 'sessionid'=>$GLOBALS['sessionid']);
            header('Content-type: application/json');
            die(json_encode($data));
    } else {
        
        require_once API_ROOT_PATH . DS . 'class' . DS . 'uploader.php';
        xoops_load('APILists');
        switch ($mode)
        {
            case "return":
                
                $sql = "INSERT INTO `" . $GLOBALS['APIDB']->prefix('jobs') . "` (`state`, `mode`, `typal`, `balance`, `hashing`, `created`, `actionable`) VALUES('queued', 'textual', 'testing', 'none', '" . ($hashing = md5(json_encode($inner))) . "', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + " . API_DELAY_SECONDS . ")";
                if ($GLOBALS['APIDB']->queryF($sql))
                {
                    $jid = $GLOBALS['APIDB']->getInsertId();
                    $sql = "INSERT INTO `" . $GLOBALS['APIDB']->prefix('routes') . "` (`jid`, `mode`, `medium`, `mimetype`, `training`, `api_url`, `subject`, `recipient_username`, `sender_username`, `recipient_name`, `sender_name`, `recipient_email`, `sender_email`, `recipient_ip`, `sender_ip`, `path`, `file`, `created`, `actionable`) VALUES('$jid', 'testing', 'image', '" . ( !isset($inner['mimetype']) ? 'text/plain' : $inner['mimetype'] ) . "', 'none', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['callback']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['subject']) . "', , '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['usernames']['recipient']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['usernames']['sender']) . "',, '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['names']['recipient']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['names']['sender']) . "', , '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['emails']['recipient']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['emails']['sender']) . "', , '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, whitelistGetIP(true)) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['sender-ip']) . "', '" . str_replace(array(API_VAR_PATH, API_PATH), '', DS . 'queuing' . DS . 'testing' . DS . 'textual') . "', '$hashing%s', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + " . API_DELAY_SECONDS . ")";
                    if ($GLOBALS['APIDB']->queryF($sql))
                    {
                        $rid = $GLOBALS['APIDB']->getInsertId();
                        
                        $fname = API_PATH . DS . 'queuing' . DS . 'testing' . DS . 'textual' . DS  . $hashing . '.msg';
                        writeRawFile($fname, $template);
                        
                        require_once API_ROOT_PATH . DS . 'class' . DS . 'sentences.php';
                        $sentences = new APISentences($inner['message']);
                        
                        $fname = API_PATH . DS . 'queuing' . DS . 'testing' . DS . 'textual' . DS  . $hashing . '.json';
                        writeRawFile($fname, json_encode($sentences->getDumpArray()));
                        
                        $fname = API_PATH . DS . 'queuing' . DS . 'testing' . DS . 'textual' . DS  . $hashing . '.inner.json';
                        writeRawFile($fname, json_encode($inner));
                        
                        foreach($sentences->getCountArray() as $key => $value)
                            $total[$key] = $total[$key] + $value;
                            
                        foreach($totals as $ikey => $value)
                            if (!$GLOBALS['APIDB']->queryF($sql = "UPDATE `" . $GLOBALS['APIDB']->prefix('jobs') . "` SET `$ikey` = '" . (is_numeric($value) ? floor( $value / ( count($totals) ) ) : mysqli_real_escape_string($GLOBALS['APIDB']->conn, $value) ) . " WHERE `jid` = '$jid'" ))
                                die("SQL Failed: $sql;");
                                
                        if (!$GLOBALS['APIDB']->queryF($sql = "UPDATE `" . $GLOBALS['APIDB']->prefix('jobs') . "` SET `updated` = UNIX_TIMESTAMP() WHERE `jid` = '$jid'"))
                            die("SQL Failed: $sql;");
                            
                    }
                }
                redirect_header($inner['return'], 0, '');
                break;
            default:
                
                $utf = array();
                $status['ham'] = $status['spam'] = 0;
                
                $sql = "INSERT INTO `" . $GLOBALS['APIDB']->prefix('jobs') . "` (`state`, `mode`, `typal`, `balance`, `hashing`, `created`, `actionable`) VALUES('queued', 'textual', 'testing', 'none', '" . ($hashing = md5_file($uploaddir . DS . $file)) . "', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + " . API_DELAY_SECONDS . ")";
                if ($GLOBALS['APIDB']->queryF($sql))
                {
                    $jid = $GLOBALS['APIDB']->getInsertId();
                    $sql = "INSERT INTO `" . $GLOBALS['APIDB']->prefix('routes') . "` (`jid`, `mode`, `medium`, `mimetype`, `training`, `api_url`, `subject`, `recipient_username`, `sender_username`, `recipient_name`, `sender_name`, `recipient_email`, `sender_email`, `recipient_ip`, `sender_ip`, `path`, `file`, `created`, `actionable`) VALUES('$jid', 'testing', 'image', '" . ( !isset($inner['mimetype']) ? 'text/plain' : $inner['mimetype'] ) . "', 'none', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['callback']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['subject']) . "', , '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['usernames']['recipient']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['usernames']['sender']) . "',, '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['names']['recipient']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['names']['sender']) . "', , '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['emails']['recipient']) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['emails']['sender']) . "', , '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, whitelistGetIP(true)) . "', '" . mysqli_real_escape_string($GLOBALS['APIDB']->conn, $inner['sender-ip']) . "', '" . str_replace(API_VAR_PATH, '', dirname($imgfile)) . "', '" . basename($imgfile) . "', UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + " . API_DELAY_SECONDS . ")";
                    if ($GLOBALS['APIDB']->queryF($sql))
                    {
                        $rid = $GLOBALS['APIDB']->getInsertId();
                    }
                }
                  
                $totals = $status = array();
                $ttlgamma = $ttlalpha = $ttlnums = 0;
                    
                $template = file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'data' . DIRECTORY_SEPARATOR . 'testing-template.diz');
                foreach(($resource = getTemplateArray($inner, '')) as $key => $value)
                    $template = str_replace("%key", $value, $template);
                $fname = API_VAR_PATH . DS . $hashing . '.msg';
                writeRawFile($fname, $template);
                $sout = array();
                $rvar = false;
                exec(sprintf(API_SPAMTESTER, $fname), $sout, $rvar);
                unlink($fname);
                $gamma = $alpha = $nums = 0;
                foreach($sout as $key => $valstore)
                {
                    if (strpos($valstore, "/")>0)
                    {
                        $parts = explode("/", $valstore);
                        if (count($parts)==2&&$parts[0]!=0&&$parts[1]!=0)
                        {
                            $nums++;
                            $alpha = $alpha + ((float)$parts[0] * 1000 + 1);
                            $gamma = $gamma + ((float)$parts[1] * 1000 + 2);
                        }
                    }
                }
                if ($nums>0)
                {
                    $alpha = $alpha / $nums;
                    $gamma = $gamma / $nums;
                }
                
                $ttlnums = $ttlnums + $nums;
                $ttlalpha = $ttlalpha + $alpha;
                $ttlgamma = $ttlgamma + $gamma;
                
                
                $sql = "SELECT max(`alpha`) as `maximum-alpha`, avg(`alpha`) as `average-alpha`, stddev(`alpha`) as `stddev-alpha`, max(`gamma`) as `maximum-gamma`, avg(`gamma`) as `average-gamma`, stddev(`gamma`) as `stddev-gamma` FROM  `" . $GLOBALS["APIDB"]->prefix("jobs") . "`";
                list($maxalpha, $avgalpha, $stdevalpha, $maxgamma, $avggamma, $stdevgamma) = $GLOBALS['APIDB']->fetchRow($GLOBALS['APIDB']->queryF($sql));
                
                if ($alpha==0 && $gamma == 0) {
                    $elite = 'ham';
                } elseif ($maxalpha>0 && $alpha < ($avgalpha - $stdevalpha) && $maxgamma>0 && $gamma < ($avggamma - $stddevgamma) || ($alpha / $gamma / 1000 * 100) < 41) {
                    $elite = 'ham';
                } elseif ($maxalpha>0 && ($ttlalpha / $ttlnums) < ($avgalpha - $stdevalpha) && $maxgamma>0 && ($ttlgamma / $ttlnums) < ($avggamma - $stddevgamma) || ($ttlalpha / $ttlgamma / 1000 * 100) < 51) {
                    $elite = 'ham';
                } else {
                    $elite = 'spam';
                }
                
                $status[$elite]++;
                
                
                if ($status['spam'] > $status['ham'])
                    $elite = 'spam';
                elseif ($status['spam'] <= $status['ham'])
                    $elite = 'ham';
                
                $fname = API_PATH . DS .'scoring' . DS . 'testing' . DS . $elite . DS . 'textual' . DS  . $hashing . '.msg';
                writeRawFile($fname, $template);
                
                $fname = API_PATH . DS .'training' . DS . $elite . DS . 'textual' . DS  . $hashing . '.msg';
                writeRawFile($fname, $template);
                
                require_once API_ROOT_PATH . DS . 'class' . DS . 'sentences.php';
                $sentences = new APISentences($inner['message']);
                
                $fname = API_PATH . DS .'scoring' . DS . 'testing' . DS . $elite . DS . 'textual' . DS  . $hashing . '.json';
                writeRawFile($fname, json_encode($sentences->getDumpArray()));
                
                foreach($sentences->getCountArray() as $key => $value)
                    $total[$key] = $total[$key] + $value;
  
                
                foreach($totals as $ikey => $value)
                    if (!$GLOBALS['APIDB']->queryF($sql = "UPDATE `" . $GLOBALS['APIDB']->prefix('jobs') . "` SET `$ikey` = '" . (is_numeric($value) ? floor( $value / ( count($totals) ) ) : mysqli_real_escape_string($GLOBALS['APIDB']->conn, $value) ) . " WHERE `jid` = '$jid'" ))
                        die("SQL Failed: $sql;");
                        
                if (!$GLOBALS['APIDB']->queryF($sql = "UPDATE `" . $GLOBALS['APIDB']->prefix('jobs') . "` SET `updated` = UNIX_TIMESTAMP() WHERE `jid` = '$jid'"))
                    die("SQL Failed: $sql;");
                    
                if (!$GLOBALS['APIDB']->queryF($sql = "UPDATE `" . $GLOBALS['APIDB']->prefix('routes') . "` SET `file` = '".$hashing."%s', `path` = '" . 'scoring' . DS . 'testing' . DS . $elite . DS . 'textual' . "'  WHERE `rid` = '$rid'"))
                    die("SQL Failed: $sql;");
                foreach($totals as $ikey => $value)
                    $totals[$ikey] = (is_numeric($value) ? floor( $value / ( count($totals) ) ) : $value );
                    
                $sql = "SELECT max(`alpha`) as `maximum-alpha`, avg(`alpha`) as `average-alpha`, stddev(`alpha`) as `stddev-alpha`, max(`gamma`) as `maximum-gamma`, avg(`gamma`) as `average-gamma`, stddev(`gamma`) as `stddev-gamma` FROM  `" . $GLOBALS["APIDB"]->prefix("jobs") . "`";
                $lestats = $GLOBALS['APIDB']->fetchArray($GLOBALS['APIDB']->queryF($sql));
                
                $data = array_merge($inner, $totals, $lestats, array('hashing' => $hashing, 'modal' => 'testing', 'typal' => 'textual', 'sessionid'=>$GLOBALS['sessionid']), array('alpha' => $ttlalpha / $ttlnums, 'gamma' => $ttlalpha / $ttlnums, 'segments' => $ttlnums));
                $data = array($elite => $data);
                
                if (isset($inner['callback']) && !empty($inner['callback']))
                {
                    setCallBackURI($inner['callback'], 290, 290, $data);
                };
                if (!empty($data))
                {
                    @APICache::write($keyname, $data, API_CACHE_SECONDS);
                    if (!$sessions = APICache::read('sessions-'.md5($_SERVER['HTTP_HOST'])))
                        $sessions = array();
                    $sessions[$keyname] = time() + API_CACHE_SECONDS;
                    @APICache::write('sessions-'.md5($_SERVER['HTTP_HOST']), $sessions, API_CACHE_SECONDS * API_CACHE_SECONDS * API_CACHE_SECONDS);
                }
        }
        
    }
}


if (function_exists('http_response_code'))
    http_response_code(200);

error_reporting(0);
if (!empty($data))
{
    @APICache::write($keyname, $data, API_CACHE_SECONDS);
    if (!$sessions = APICache::read('sessions-'.md5($_SERVER['HTTP_HOST'])))
        $sessions = array();
    $sessions[$keyname] = time() + API_CACHE_SECONDS;
    @APICache::write('sessions-'.md5($_SERVER['HTTP_HOST']), $sessions, API_CACHE_SECONDS * API_CACHE_SECONDS * API_CACHE_SECONDS);
}

if (function_exists('mb_http_output')) {
    mb_http_output('pass');
}

$GLOBALS['APIDB']->queryF("COMMIT");

switch ($state) {
    case 'return':
        if (function_exists('http_response_code'))
            http_response_code(301);
            header('Location: ' . $inner['return']);
            exit(0);
            break;
    case 'raw':
        header('Content-type: application/x-httpd-php');
        echo ('<?php'."\n\n".'return ' . var_export($data, true) . ";\n\n?>");
        break;
    case 'json':
        header('Content-type: application/json');
        die(json_encode($data));
        break;
    case 'serial':
        header('Content-type: text/plain');
        die(serialize($data));
        break;
    case 'xml':
        header('Content-type: application/xml');
        $dom = new XmlDomConstruct('1.0', 'utf-8');
        $dom->fromMixed(array('root'=>$data));
        die($dom->saveXML());
        break;
}
    