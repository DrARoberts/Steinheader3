<?php
echo base64_encode("dr.x@8bit.institute");
echo "\n\n\n\n";
echo base64_encode("n0bux5t||||-");